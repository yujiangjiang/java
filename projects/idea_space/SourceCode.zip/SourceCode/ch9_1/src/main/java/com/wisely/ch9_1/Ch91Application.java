package com.wisely.ch9_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch91Application {

    public static void main(String[] args) {
        SpringApplication.run(Ch91Application.class, args);
    }
}
