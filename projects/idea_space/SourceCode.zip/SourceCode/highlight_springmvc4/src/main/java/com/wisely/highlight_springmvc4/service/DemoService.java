package com.wisely.highlight_springmvc4.service;

import org.springframework.stereotype.Service;

@Service
public class DemoService {
	
	public String saySomething(){
		return "hello";
	}

}
