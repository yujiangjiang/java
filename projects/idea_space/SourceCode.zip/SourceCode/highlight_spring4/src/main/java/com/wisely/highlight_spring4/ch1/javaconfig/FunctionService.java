package com.wisely.highlight_spring4.ch1.javaconfig;
//1
public class FunctionService {
	
	public String sayHello(String word){
		return "Hello " + word +" !"; 
	}


}
