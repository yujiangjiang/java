package com.wisely.ch10war;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch10warApplication {

    public static void main(String[] args) {
        SpringApplication.run(Ch10warApplication.class, args);
    }
}
